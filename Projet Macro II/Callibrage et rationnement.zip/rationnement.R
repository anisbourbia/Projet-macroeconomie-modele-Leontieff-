#rationnement individuel de l'industrie
#r�solution par gradient analytique

#I- structures

n<-3 #nombre de biens
p<-2 #nombre de facteurs
q<-4 #nombre de classes sociales
m<-matrix(0,n,n)  #consommations intermediaires en volume
a<-matrix(0,n,n)  #coefficients de Leontieff
r<-matrix(0,p,n)	#r�mun�rations unitaires des facteurs
v<-matrix(0,p,n)  #composantes des valeurs ajout�es
d<-matrix(0,n,q)	#demande finale par classe sociale en volume, un bien par ligne
s<-matrix(0,p,q)  #cl�s de r�partition des revenus par facteur et par classe
C<-rep(0,n)		#consommations minimales vitales selon la fonction d'utilit� Stone-Geary
E<-rep(0,n)		#exposants de la fonction d'utilit� Stone-Geary
P<-rep(1,n)		#prix
V<-rep(0,n)		#valeur ajout�e unitaire, par secteur
Y<-rep(0,n)		#offre en volume, par secteur
D<-rep(0,n)		#demande finale en volume par secteur
M<-rep(0,q)		#revenu total par classe sociale


Id<-function(nn){
  Idn<-matrix(0,nn,nn)
  for (i in 1:nn) {Idn[i,i]<-1}
  return(Idn)
}

#II- situation de r�f�rence et param�tres

#matrice des comptes sociaux:
m[1,1]<-10; m[1,2]<-40; m[1,3]<-6;
m[2,1]<-43; m[2,2]<-50; m[2,3]<-10;
m[3,1]<-15; m[3,2]<-40; m[3,3]<-2;

v[1,1]<-42.5; v[1,2]<-19; v[1,3]<-10.2;
v[2,1]<-7.5; v[2,2]<-19; v[2,3]<-40.8;

#structure sociale: cl�s de r�partition des revenus des facteurs
s[1,1]<-0.25;s[1,2]<-0.25;s[1,3]<-0.25;s[1,4]<-0.25
s[2,1]<-0.0117013372956908;s[2,2]<-0.11998514115899;s[2,3]<-0.179420505200594;s[2,4]<-0.688893016344725

#matrice de Leontieff et va unitaires:
#calcul de l'offre en volume par secteur
for (i in 1:n) {Y[i]<-rep(1,n)%*%m[1:n,i]+rep(1,p)%*%v[1:p,i]}

#calcul de la matrice des coeff de Leontief-volumes
for (i in 1:n) {for (j in 1:n) {a[i,j]<-m[i,j]/Y[j]}}

#calcul des va unitaires
for (i in 1:p) {for (j in 1:n) {r[i,j]<-v[i,j]/Y[j]}}
V<-rep(1,p)%*%r

#fonction d'utilit� Stone-Geary
#param�tres (calcul�s � partir du calibrage)
C[1]<-40
C[2]<-13.516592  
C[3]<-3.266935
E[1]<-0.26034184 
E[2]<-0.59792232 
E[3]<-0.08242759

stone_geary<-function(di) {
  u<-((di[1]-C[1])^E[1])*((di[2]-C[2])^E[2])*((di[3]-C[3])^E[3])
  return(u)
}

d2max <- 45 # = 85% de la demande sans contrainte
ymax<- 125

#III- d�finition des fonctions n�cessaires:

#fonction inversion de matrice
inv<-function(mat){
  n<-nrow(mat)
  Idn<-matrix(0,n,n)
  matmoins1<-matrix(0,n,n)
  for (i in 1:n) {Idn[i,i]<-1}
  for (i in 1:n) {
    matmoins1[,i]<-solve(mat,Idn[,i])
  }
  return(matmoins1)
}

#fonction de demande non rationn�e par bien et par classe
dem<-function(M) {
  depmin<-t(C)%*%P
  d<-matrix(0,n,q)
  for (k in 1:q) {
    for (i in 1:n){
      d[i,k]<-(C[i]+E[i]*((M[k]/s[1,k])/P[i]-depmin/P[i]))*s[1,k]
    }
  }
  return(d)
}

#fonction de demande avec rationnement individuel sur le bien 2; � hauteur de d2max par individu
dem_ri<-function(M) {
  #calcul sans rationnement
  d <- dem(M)
  for (j in 1:q) {
    if (d[2,j] > d2max*s[1,j]) {
      mi <- M[j]/s[1,j]-P[2]*d2max
      d[3,j] <- (C[3]+(1/P[3])*(E[3]/(E[1]+E[3]))*(mi-P[1]*C[1]-P[3]*C[3]))*s[1,j]
      d[1,j] <- (C[1]+(1/P[1])*(E[1]/(E[1]+E[3]))*(mi-P[1]*C[1]-P[3]*C[3]))*s[1,j]
      d[2,j] <- d2max*s[1,j]
    }
  }
  
  return(d)
}

#fonction de calcul des revenus des classes � partir de la demande finale
rev<-function(d) {
  #calcul de la demande finale totale par bien
  D<-d%*%rep(1,q)
  #mise � jour de l'offre totale par bien en volume
  Y<-inv(Id(n)-a)%*%D
  #calcul des r�mun�rations des facteurs
  for (i in 1:p) {for (j in 1:n) {v[i,j]<-r[i,j]*Y[j]}}
  #partage des revenus
  M<-t(s)%*%v%*%rep(1,n)
  return(M)
}

#matrice A(d) pour le calcul du gradient
A <- function(d){
  Ax <- matrix(0,n,q)
  for (i in 1:n) {Ax[i,] <- (E[i]/P[i])*rep(1,q)}
  for (j in 1:q) {
    if (d[2,j] >= d2max*s[1,j]) {
      Ax[2,j] <- 0
      for (i in 1:n) { if (i != 2) { Ax[i,j] <- (E[i]/P[i])*(1/(sum(E)-E[2])) } }
    }
  }
  return(Ax)
}

#IV- calculs d'initialisation

#revenus de d�part
M<-t(s)%*%v%*%rep(1,n)

#consommations initiales aux prix 1
d<-dem(M)

#V- calcul de l'�quilibre

#demande->revenus->demande...
F<-function(d_in){
  #d_in: matrice de consommations en volume en entr�e
  M<-rev(d_in)
  d_out<-dem_ri(M)
  return(d_out)
}

desequilibre<-function(d_in){
  deseq<-F(d_in)-d_in
  deseq<-sqrt(sum(deseq^2))
  return(deseq)
}

#gradient analytique
gradient<-function(d_in){
  d_out<-F(d_in)
  y<-rep(0,n)
  grad<-matrix(0,n,q)
  Idn <- Id(n)
  for (k in 1:n){
    Fk<-inv(Idn-a)%*%Idn[,k]
    y[k]<-y[k]+t(E/P)%*%(d_out-d_in)%*%(t(s)%*%r%*%Fk)
  }
  for (l in 1:q){
    for (k in 1:n){
      grad[k,l]<--2*(d_out[k,l]-d_in[k,l])+2*y[k]
    }
  }
  return(grad)
}

#descente gradient analytique
mu <- 1e-5
x <- F(d) #pour commencer � l'int�rieur des contraintes
nn <- 1
err <- 1
while (err > 10^-10 & nn <=1000000) {
  u <- gradient(x)
  normu<-sqrt(sum(u^2))
  x <- x-mu*u
  err <- mu*sqrt(sum(u^2))
  print(desequilibre(x))
  print(normu)
  print(err)
  print(nn)
  flush.console()
  nn <- nn+1
}