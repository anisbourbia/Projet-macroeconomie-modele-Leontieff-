#calibrage de l'utilit� stone-geary
#inputs: d = matrice des consommations individuelles en valeur par bien x classe
#m = revenus individuels par classe
#C[1] = consommation alimentaire minimale vitale

#I - D�clarations

n <- 3		  #n doit �tre >= 2
q <- 4
d <- matrix (0,n,q) #consommation individuelle des classes en valeur
E <- rep(0,n)       #elasticit�s
C <- rep(0,n)	  #consommations minimales vitales
m <- rep(0,q)	  #budget individuelle par classe

#II- Donn�es de r�f�rences

C[1] <- 40
d <- matrix(c(45,25,4.85,55,40,9,60,50,10,88,145,24.15),3,4)
m <- c(29.85,104,120,257.15)

#III- Fonctions

m_c <- function(x) { #somme des carr�s des diff�rences � minimiser
	#x est la concat�nation de C[2:n] et de E
	mc <- 0
	#deconcatenation:
	C[2:n] <- x[1:(n-1)]
	E <- x[n:(2*n-1)]
	for (i in 1:n) {
		for (j in 1:q){
			mc <- mc+(d[i,j]-C[i]-E[i]*(m[j]-sum(C)))^2
		}
	}
	return(mc)
	}
	
grad_mc <- function(x) { #gradient de m_c
	
	}

#IV- Point d'amor�age (calcul� sur les individus j = 1 et j = 2)

#Point d'amor�age
#calcul des Ei
Ei <- matrix(0,q,q)
meanE <- rep(0,n)
for (i in 1:n) {
	compteur <- 0     #pour calculer la moyenne des Ei
	sumEi <- 0        #pour calculer la moyenne des Ei
	sumsquaresEi <- 0 #pour calculer la variance des Ei
	for (j1 in 1:q) {
		for (j2 in 1:q) {
			if (j1 != j2) {
				Ei[j1,j2] <- (d[i,j2]-d[i,j1])/(m[j2]-m[j1])
				compteur <- compteur + 1
				sumEi <- sumEi + Ei[j1,j2]
				sumsquaresEi <- sumsquaresEi + (Ei[j1,j2])^2
			}
		}
	}
	meanE[i] <- sumEi / compteur
	varEi <- sumsquaresEi / compteur - (meanE[i])^2
	relative_devEi <- sqrt(varEi)/meanE[i]
	print(Ei) #pour voir la stabilit� des Ei
	print(relative_devEi)
}
E <- meanE
#pour avoir sum(Ei)=1
for (i in 1:n) {
	E[i] <- E[i]/sum(E)
}
#calcul de la somme des Ci
sigmac <- m[1]-(d[1,1]-C[1])/E[1]
for (i in 2:n) {
	#calcul de Ci
	C[i] <- d[i,1]-E[i]*(m[1]-sigmac)
}

#V- Descente du gradient
mu <- 1e-3
x <- c(C[2:n],E) #initialisation au point d'amor�age
mc <- m_c(x)
nn <- 1
dmc <- 1
f<-1e4 #pour le rescaling de certaines composantes du gradient
while (abs(dmc) > 10^-10 & nn <= 1000000) {
	u <- grad_mc(x)
	#projection du gradient sur le sev de la contrainte sum(E)=1
	moyE <- mean(u[n:(2*n-1)])
	u[n:(2*n-1)] <- u[n:(2*n-1)] - moyE
	u[n:(2*n-1)] <- u[n:(2*n-1)]/f #rescaling des 3 derni�res composantes du gradient
	x[n:(2*n-1)] <- x[n:(2*n-1)]*f
	normu<-sqrt(sum(u^2))
	x <- x-mu*u
	x[n:(2*n-1)] <- x[n:(2*n-1)]/f
	dmc <- mc-m_c(x)
	mc <- mc-dmc
	err <- mu*sqrt(sum(u^2))
	print(mc)
	print(dmc)
	print(normu)
	print(err)
	print(nn)
	flush.console()
	nn <- nn+1
}

#VI- Descente quadratique � E fix� pour v�rifier si on n'est pas dans un minimum local
mu <- 1e-3
nn <- 1
dmc <- 1
while (abs(dmc) > 10^-15 & nn <= 10000) {
	u <- grad_mc(x)
	u[n:(2*n-1)] <- 0
	normu<-sqrt(sum(u^2))
	x <- x-mu*u
	dmc <- mc-m_c(x)
	mc <- mc-dmc
	err <- mu*sqrt(sum(u^2))
	print(mc)
	print(dmc)
	print(normu)
	print(err)
	print(nn)
	flush.console()
	nn <- nn+1
}



#commentaires sur l'execution:
#r�sultat apr�s 832432 it avec mu = 1e-4
#normu = 1e-3
#x <- c(-0.59154194,5.32806358,0.23544331,0.69143491,0.06640523)
#une autre execution avec les m�mes param�tres!
#x <- c(-0.82711226,5.27371945,0.23688916,0.69291282,0.06788313) #avec mu=1e-3 m�me resultat
#et aussi, presque mu=1e-2!
#la boucle quadratique apr�s n'a rien chang� -> c'�tait un minium absolu
#rm(list = ls(all = TRUE)): efface tout